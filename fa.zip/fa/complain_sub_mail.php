<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;
require 'PHPMailer/vendor/autoload.php';
session_start();
$fem=$_SESSION['var'];
$s1=$_SESSION['var1'];
$s2=$_SESSION['var2'];
$mail = new PHPMailer();
$mail->isSMTP(); 
$mail->SMTPAuth = true;                                     // Set mailer to use SMTP
$mail->Host = 'smtp.gmail.com'; 
$mail->SMTPDebug = 0;                      // Specify main and backup server
$mail->Username = 'icmsiiitbh@gmail.com';                   // SMTP username
$mail->Password = 'Test@123';               // SMTP password
$mail->SMTPSecure = 'tls';                            // Enable encryption, 'ssl' also accepted
$mail->Port = 587;                                    //Set the SMTP port number - 587 for authenticated TLS
$mail->setFrom('icmsiiitbh@gmail.com', 'ICMS IIIT Bhagalpur');     //Set who the message is to be sent from
//$mail->addReplyTo('labnol@gmail.com', 'First Last');  //Set an alternative reply-to address
$mail->addAddress($fem, '');  // Add a recipient
//$mail->addAddress('ellen@example.com');               // Name is optional
//$mail->addCC('studentaffairsiiitbh@gmail.com');
//$mail->addBCC('bcc@example.com');
//$mail->WordWrap = 50;                                 // Set word wrap to 50 characters
//$mail->addAttachment('/usr/labnol/file.doc');         // Add attachments
//$mail->addAttachment('/images/image.jpg', 'new.jpg'); // Optional name
$mail->isHTML(true);                                  // Set email format to HTML
$mail->Subject = 'Status of complaint';
$mail->Body    = 'Dear Faculty/Staff <br /> Your Complaint Status is: <b>'.$s1.'</b>.<br /> Remarks of your complaint: <b> '.$s2.'</b>';
$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
if(!$mail->send()) {
   echo 'Message could not be sent.';
   //echo 'Mailer Error: ' . $mail->ErrorInfo;
   exit;
}
echo 'Action has been updated Successfully';
?>