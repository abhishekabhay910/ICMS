
<?php 
session_start();
include('includes/config.php');
//prompt function
    function prompt($prompt_msg){
        echo("<script type='text/javascript'> var answer = prompt('".$prompt_msg."'); </script>");

        $answer = "<script type='text/javascript'> document.write(answer); </script>";
        return($answer);
        }

if(isset($_POST['usname'])){
$x=$_POST['email']. "@iiitbh.ac.in";
$_SESSION['var']=$x; 
                $result=mysqli_query($con,"select studEmail from  stud where studEmail = '$x' ");
                $count=mysqli_num_rows($result);
                if(empty($count)){

                   echo("<script type='text/javascript'> var answer = alert('This Email is Not Registered'); </script>");

                }
                else
                {
                    header("location:forget_testmail.php");


                    
                }
            }
 ?>

<!DOCTYPE html>
<html>
<head>
<title>Student Login</title>
<style>
body{
	font-family: calibri;
}
.tblLogin {
	border: #95bee6 1px solid;
    background: #d1e8ff;
    border-radius: 4px;
    max-width: 300px;
	padding:20px 30px 30px;
	text-align:center;
}
.tableheader { font-size: 20px; }
.tablerow { padding:0px; }
.error_message {
	color: #b12d2d;
    background: #ffb5b5;
    border: #c76969 1px solid;
}
.message {
	width: 100%;
    max-width: 300px;
    padding: 10px 30px;
    border-radius: 4px;
    margin-bottom: 5px;    
}
.login-input {
	border: #CCC 1px solid;
    padding: 10px 20px;
	border-radius:4px;
}
.btnSubmit {
	padding: 10px 20px;
    background: #2c7ac5;
    border: #d1e8ff 1px solid;
    color: #FFF;
	border-radius:4px;
}
</style>
<style>
label, input {
    position: relative;
    display: block;
    padding-right: 12px;
    width: 300px;
    box-sizing: border-box;
}

label::after {
    content: '' attr(data-domain);
    position: absolute;
    top: 7px;
    left: 180px;
    font-family: arial, helvetica, sans-serif;
    font-size: 17px;
    display: block;
    color: rgba(0, 0, 0, 0.6);
    font-weight: bold;
}
</style>

</head>
<body>
 		<div>
        <center>
        <img src="images/logo.png" height="100px" width="1120px">
        <hr width="1120px">
        </center>
        </div>
<form name="frmUser" method="post" action="">
<br><br><br><br><br><br>
<center>
	<div class="tblLogin">		
		<div class="tableheader">Enter Your College Email ID</div>
		<br><br>
        <a href="index.php">
        <img src="images/back.png" width="40px"  height="40px">
        </a>
        <br><br>
        <div class="tablerow">
            <label data-domain="@iiitbh.ac.in">
            <input type="email" name="email"  placeholder="Username" class="login-input" required>
        </label>
        </div>
        <br><br>
        <div class="tableheader"><input type="submit" name="usname" value="Submit" class="btnSubmit"></div>
		</div>
</center>
</form>
</body>
</html>