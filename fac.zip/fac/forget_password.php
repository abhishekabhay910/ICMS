<?php
include('includes/config.php');
error_reporting(0);

session_start();
$x=$_SESSION['var2'];
if ($_POST["password"] != $_POST["confirm_password"]) {
   echo("<script type='text/javascript'>  alert('Password did not match.'); </script>");
}
 else
 {
      //for email
if(isset($_POST['submit']))
{
	
	$password1=md5($_POST['password']);
	$status=1;
	$query=mysqli_query($con,"update facstaff set password='$password1' where empEmail='$x' " );
	$msg="Password has been changed successfully. Now You can login !";
}
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Dashboard">
    <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">

    <title>ICMS | Forget Password</title>
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/style-responsive.css" rel="stylesheet">
    	<script>
function userAvailability() {
$("#loaderIcon").show();
jQuery.ajax({
url: "check_availability.php",
data:'email='+$("#email").val(),
type: "POST",
success:function(data){
$("#user-availability-status1").html(data);
$("#loaderIcon").hide();
},
error:function (){}
});
}
</script>
  </head>

  <body>
  	<div>
        <center>
        <img src="images/logo.png" height="100px" width="1120px">
        <hr width="1120px">
        </center>
        </div>

	  <div id="login-page">
	  	<div class="container">
		      <form class="form-login" method="post">
		        <h2 class="form-login-heading">Recover Password</h2>
		        <br>
		        <center>
		        <a href="index.php"><h4><b>Home</b></h4></a>
		        </center>
		        <p style="padding-left: 1%; color: green">
		        	<?php if($msg){
echo htmlentities($msg);
		        		}?>


		        </p>
		        <div class="login-wrap">
		        	
		        	
		        	<input type="email" name="useremail" required="required" value="<?php echo htmlentities($x);?>" readonly class="form-control">
		        	<br>
		         
		            <input type="password" class="form-control" placeholder=" New Password" required="required" name="password"><br >
		            <input type="password" class="form-control" placeholder="Confirm Password" required="required" name="confirm_password"><br >
		            <button class="btn btn-theme btn-block"  type="submit" name="submit" id="submit"><i class="fa fa-user"></i> Submit</button>
		            <hr>
		            
		          
		
		        </div>
		
		      
		
		      </form>	  	
	  	
	  	</div>
	  </div>

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>

    <!--BACKSTRETCH-->
    <!-- You can use an image of whatever size. This script will stretch to fit in any screen size.-->
    <script type="text/javascript" src="assets/js/jquery.backstretch.min.js"></script>
    <script>
        $.backstretch("assets/img/login-bg.jpg", {speed: 500});
    </script>


  </body>
</html>