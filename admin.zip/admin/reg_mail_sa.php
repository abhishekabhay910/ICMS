<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;
require 'PHPMailer/vendor/autoload.php';
session_start();
$sem=$_SESSION['var'];
$pswd=$_SESSION['var1'];
$mail = new PHPMailer();
$mail->isSMTP(); 
$mail->SMTPAuth = true;                                     // Set mailer to use SMTP
$mail->Host = 'smtp.gmail.com'; 
$mail->SMTPDebug = 0;                      // Specify main and backup server
$mail->Username = 'icmsiiitbh@gmail.com';                   // SMTP username
$mail->Password = 'Test@123';               // SMTP password
$mail->SMTPSecure = 'tls';                            // Enable encryption, 'ssl' also accepted
$mail->Port = 587;                                    //Set the SMTP port number - 587 for authenticated TLS
$mail->setFrom('icmsiiitbh@gmail.com', 'ICMS IIIT Bhagalpur');     //Set who the message is to be sent from
//$mail->addReplyTo('labnol@gmail.com', 'First Last');  //Set an alternative reply-to address
$mail->addAddress($sem, '');  // Add a recipient
//$mail->addAddress('ellen@example.com');               // Name is optional
//$mail->addCC('studentaffairsiiitbh@gmail.com');
//$mail->addBCC('bcc@example.com');
//$mail->WordWrap = 50;                                 // Set word wrap to 50 characters
//$mail->addAttachment('/usr/labnol/file.doc');         // Add attachments
//$mail->addAttachment('/images/image.jpg', 'new.jpg'); // Optional name
$mail->isHTML(true);                                  // Set email format to HTML
$mail->Subject = 'Successfully Registered';
$mail->Body    = 'Dear Sir/Mam,<br />Your have been successfully registered as a member of Student Affairs Board IIIT Bhagalpur.<br />Username: <b>'.$sem.'</b><br />Password: <b>'.$pswd.'</b>';
$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
if(!$mail->send()) {
   echo 'Message could not be sent.';
   header("location:manage-sa.php");
   //echo 'Mailer Error: ' . $mail->ErrorInfo;
   exit;
}
//echo '<script> alert("Your complaint has been successfully filled and your complaintno is  "+"''")</script>';
echo 'Message has been sent';
header("location:manage-sa.php");

?>