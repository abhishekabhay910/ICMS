<?php
session_start();
error_reporting(0);
include('include/config.php');
require('fpdf.php');
//$con=mysqli_connect('localhost','root','');
//mysqli_select_db($con,'cms');
function Footer()
{
    // Position at 1.5 cm from bottom
    $this->SetY(-15);
    // Arial italic 8
    $this->SetFont('Arial','I',8);
    // Page number
    $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
}

$pdf = new FPDF();
$pdf->AddPage();
    // Logo
   // $this->Image('logo.png',10,6,30);
    // Arial bold 15
    $pdf->SetFont('Arial','B',15);
    // Move to the right
    $pdf->Cell(70);
    // Title
    $pdf->Cell(50,5,'Indian Institute of Informtion Technology',0,1,'C');
    // Line break
	$pdf->SetFont('Arial','B',10);
	$pdf->cell(80);
	$pdf->cell(50,5,'Bhagalpur,813210',0,1,'c');
	$pdf->cell(85);
	$pdf->cell(50,5,'Bihar,India',0,1,'c');
	$pdf->cell(75);
	$pdf->cell(50,5,'Internal Complaint Details',0,1,'c');
	//$this->Line(0, 39, 280, 39);
	//$this->Line(5, 39, 280, 39);
    $pdf->Ln(8);

//$query=mysqli_query($con,"select * from studtblcomplaints where userId='".$GET['id']."'");
  
  $sem=$_SESSION['var'];
  $com=$_SESSION['var1'];
  $query = mysqli_query($con,"SELECT * FROM studtblcomplaints,stud where  complaintNumber='$com' and id = userId" );
 //$data = mysqli_num_rows($query);
$data=mysqli_fetch_array($query);

$id=$data['category'];
$qu = mysqli_query($con,"SELECT categoryName FROM studcategory where id ='$id'" );
$data1=mysqli_fetch_array($qu); 	
	$pdf->SetFont('Arial','B',12);
	$pdf->cell(10);
	$pdf->cell(50,10,'COMPLAINT NO.:',0,0);
	$pdf->SetFont('Arial','',12);
	$pdf->cell(60,10,$com,0,1);
	$pdf->SetFont('Arial','B',12);
	$pdf->cell(10);
	$pdf->cell(50,8,'Complainant Name:',0,0);
	$pdf->SetFont('Arial','',12);
	$pdf->cell(50,8,$data['fullName'],0,1);
	$pdf->SetFont('Arial','B',12);
	$pdf->cell(10);
	$pdf->cell(50,8,'ROLL NO.:',0,0);
	$pdf->SetFont('Arial','',12);
	$pdf->cell(50,8,$data['userId'],0,1);
	$pdf->SetFont('Arial','B',12);
	$pdf->cell(10);
	$pdf->cell(50,8,'BRANCH:',0,0);
	$pdf->SetFont('Arial','',12);
	$pdf->cell(50,8,$data['branch'],0,1);
	$pdf->SetFont('Arial','B',12);
	$pdf->cell(10);
	$pdf->cell(50,8,'Catogory Of Complaint:',0,0);
	$pdf->SetFont('Arial','',12);
	$pdf->cell(50,8,$data1['categoryName'],0,1);
	$pdf->SetFont('Arial','B',12);
	$pdf->cell(10);
	$pdf->cell(50,8,'Title Of Complaint:',0,0);
	$pdf->SetFont('Arial','',12);
	$pdf->cell(50,8,$data['noc'],0,1);
	$pdf->SetFont('Arial','B',12);
	$pdf->cell(10);
	$pdf->cell(50,8,'Complaint Details:',0,1);
	$pdf->SetFont('Arial','',12);
	$pdf->cell(10);
	//$cellWidth=$pdf->GetStringWidth($data['complaintDetails']);
	$pdf->Multicell(150,8,$data['complaintDetails'],0,1);
$pdf->Output();
?>